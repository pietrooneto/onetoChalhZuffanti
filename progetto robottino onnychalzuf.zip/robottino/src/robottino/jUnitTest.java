package robottino;

import static org.junit.Assert.*;

import org.junit.Test;

public class jUnitTest {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
